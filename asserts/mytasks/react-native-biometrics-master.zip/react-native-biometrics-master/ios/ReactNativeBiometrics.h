//
//  ReactNativeBiometrics.h
//
//  Created by Brandon Hines on 4/3/18.
//

#import <React/RCTBridgeModule.h>

@interface ReactNativeBiometrics : NSObject <RCTBridgeModule>

@end
