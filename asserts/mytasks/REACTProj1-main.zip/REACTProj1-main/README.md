# REACTProj1

npm i --save-dev @types/react-stepper-horizontal

npm install @types/react

To run the project first install all the node modules and update them.
Then start running the application.

To start the Backend first install the mysql workbench and create a database name project and table backend
containing the values id(int) inverter(varchar).Then run the java application with the port number 8080.


To create values in the droopdown go to the database and create the new values which you want to use and run them.

You can ignore the Solution part where we get all values except the total wattage preloaded.