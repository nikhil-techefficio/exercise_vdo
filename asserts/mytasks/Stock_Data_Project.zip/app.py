
from flask import Flask, render_template, send_from_directory
import pandas as pd
import os

app = Flask(__name__)

# Load Excel data
def load_data():
    file_path = "static/Stock_Data_Template.xlsx"
    if os.path.exists(file_path):
        return pd.read_excel(file_path)
    else:
        return pd.DataFrame()

@app.route('/')
def index():
    # Load data from Excel
    data = load_data()
    if data.empty:
        return "No data available. Please make sure the Excel file is in the 'static' folder."

    # Convert data to HTML table
    table = data.to_html(classes='table table-striped', index=False)
    return render_template('index.html', table=table)

@app.route('/download')
def download():
    # Serve the Excel file for download
    return send_from_directory('static', 'Stock_Data_Template.xlsx', as_attachment=True)

if __name__ == "__main__":
    app.run(debug=True)
