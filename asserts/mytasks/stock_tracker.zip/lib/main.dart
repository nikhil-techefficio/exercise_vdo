// Import necessary Flutter packages
import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;

void main() {
  runApp(StockApp());
}

class StockApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Stock Tracker',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: StockHomePage(),
    );
  }
}

class StockHomePage extends StatefulWidget {
  @override
  _StockHomePageState createState() => _StockHomePageState();
}

class _StockHomePageState extends State<StockHomePage> {
  // Sample stock data
  List<Map<String, dynamic>> stocks = [
    {"name": "Zomato", "symbol": "ZOMATO.NS", "target": 173},
    {"name": "Suzlon Energy", "symbol": "SUZLON.NS", "target": 44},
    {"name": "Wipro", "symbol": "WIPRO.NS", "target": 296},
  ];

  // Function to fetch stock prices
  Future<void> fetchStockPrices() async {
    for (var stock in stocks) {
      final url = 'https://query1.finance.yahoo.com/v7/finance/quote?symbols=${stock['symbol']}';
      try {
        final response = await http.get(Uri.parse(url));
        if (response.statusCode == 200) {
          final data = json.decode(response.body);
          final price = data['quoteResponse']['result'][0]['regularMarketPrice'];
          setState(() {
            stock['currentPrice'] = price;
          });
        } else {
          setState(() {
            stock['currentPrice'] = 'Error';
          });
        }
      } catch (e) {
        setState(() {
          stock['currentPrice'] = 'Error';
        });
      }
    }
  }

  @override
  void initState() {
    super.initState();
    fetchStockPrices();
    Timer.periodic(Duration(seconds: 15), (timer) {
      fetchStockPrices();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Stock Tracker'),
      ),
      body: ListView.builder(
        itemCount: stocks.length,
        itemBuilder: (context, index) {
          final stock = stocks[index];
          return Card(
            margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
            child: ListTile(
              title: Text(stock['name']),
              subtitle: Text('Target: ₹${stock['target']}'),
              trailing: Text(
                stock['currentPrice'] != null
                    ? '₹${stock['currentPrice']}'
                    : 'Loading...',
                style: TextStyle(
                  color: Colors.green,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
