/**
* Pure CSS Loading Spinner with CSS3 step()
*/