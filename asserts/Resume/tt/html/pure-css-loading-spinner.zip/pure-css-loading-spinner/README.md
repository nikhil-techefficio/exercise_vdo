# Pure CSS Loading Spinner

A Pen created on CodePen.io. Original URL: [https://codepen.io/joglr/pen/ALNdZP](https://codepen.io/joglr/pen/ALNdZP).

A loading spinner, made exclusively with HTML and CSS.