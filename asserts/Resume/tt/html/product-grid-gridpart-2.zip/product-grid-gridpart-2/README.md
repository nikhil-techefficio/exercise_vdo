# Product Grid (Grid) - Part 2

A Pen created on CodePen.io. Original URL: [https://codepen.io/michaelmcshinsky/pen/VwxKBM](https://codepen.io/michaelmcshinsky/pen/VwxKBM).

First attempt at a three part project using mostly HTML and CSS to create interchangeable product list/grid. Inspiration from Amazon Mobile Product Grid options. Any feedback is appreciated.