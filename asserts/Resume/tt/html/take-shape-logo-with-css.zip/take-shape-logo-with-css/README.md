# TAKE SHAPE Logo with CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/mikegolus/pen/ZaqdgP](https://codepen.io/mikegolus/pen/ZaqdgP).

Fun html and css recreation of the TAKE SHAPE logo