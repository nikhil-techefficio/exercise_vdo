# Facebook Reactions - Pure CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/deividmarques/pen/wGvbwY](https://codepen.io/deividmarques/pen/wGvbwY).

Facebook Reactions developed only HTML and CSS.