# Website Layout in Html & Css

A Pen created on CodePen.io. Original URL: [https://codepen.io/SufianAr/pen/xZxmNB](https://codepen.io/SufianAr/pen/xZxmNB).

Html and Css layout for websites