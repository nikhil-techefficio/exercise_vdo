# #codevember 20 - BB8

A Pen created on CodePen.io. Original URL: [https://codepen.io/phcacique/pen/rWyrbQ](https://codepen.io/phcacique/pen/rWyrbQ).

BB8 checkbox only HTML and CSS