# CSS Only Accordion

A Pen created on CodePen.io. Original URL: [https://codepen.io/vinsongrant/pen/qbGKed](https://codepen.io/vinsongrant/pen/qbGKed).

An accordion built  with only HTML and CSS. This method utilizes a checkbox as the toggle switch for the content.