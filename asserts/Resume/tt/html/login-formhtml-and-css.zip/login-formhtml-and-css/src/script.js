/* 

Sign up form
Author: Pali madra
website: http://www.agilewebsitedev.com
                   and
         http://www.agileseo.net
         
*/