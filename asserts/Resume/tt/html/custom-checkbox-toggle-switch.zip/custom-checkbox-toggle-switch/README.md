# Custom Checkbox / Toggle Switch

A Pen created on CodePen.io. Original URL: [https://codepen.io/thelaazyguy/pen/MvqpPr](https://codepen.io/thelaazyguy/pen/MvqpPr).

Collection of four toggle switches made with html and css without a single line of javascript. Two of the switches are made with the help of svg also.