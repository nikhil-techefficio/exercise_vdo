# CasioPT-1.css

A Pen created on CodePen.io. Original URL: [https://codepen.io/fossheim/pen/VweaNYW](https://codepen.io/fossheim/pen/VweaNYW).

Vintage Casio PT-1 keyboard drawn entirely with HTML and CSS; using divs, gradients and box-shadows. 

Tutorials on how to make drawings like this: 
https://fossheim.io/writing/posts/css-macintosh/
https://fossheim.io/writing/posts/css-polaroid-camera/

GitHub repo with my CSS drawings:
https://github.com/sarahfossheim/art.css

If you like my work: 
https://www.buymeacoffee.com/fossheim
https://www.patreon.com/fossheim