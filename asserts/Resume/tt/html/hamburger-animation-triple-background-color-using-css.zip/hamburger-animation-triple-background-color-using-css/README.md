# Hamburger animation & Triple background color using CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/himalayasingh/pen/mNOJPM](https://codepen.io/himalayasingh/pen/mNOJPM).

Hamburger animation & triple background color animation created only using HTML and CSS.