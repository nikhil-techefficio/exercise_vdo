/****

Please view in full screen mode

A pure html and css based Halloween scenery to spook you off :) made for the #HauntedCodingWeek

Some more updated over the weekend to be done. 

any suggestions are welcomed, or feel free to fork and update

https://twitter.com/CodingUk

Follow me on Facebook : https://www.facebook.com/Freelance.Web.Developer.Designer

Follow me on twitter: https://twitter.com/amyth91

****/