# A Halloween weekend

A Pen created on CodePen.io. Original URL: [https://codepen.io/amyth91/pen/rNgrjp](https://codepen.io/amyth91/pen/rNgrjp).

A pure html and css based Halloween scenery to spook you off :) made for the #HauntedCodingWeek

https://twitter.com/CodingUk