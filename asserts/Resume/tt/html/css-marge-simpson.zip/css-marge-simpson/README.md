# CSS Marge Simpson

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/ZwKpdR](https://codepen.io/alvaromontoro/pen/ZwKpdR).

Marge Simpson drawn using HTML and CSS