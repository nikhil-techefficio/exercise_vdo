# Pure CSS Drawer Menu with overlay

A Pen created on CodePen.io. Original URL: [https://codepen.io/equinusocio/pen/wPvvmv](https://codepen.io/equinusocio/pen/wPvvmv).

This pen show how to build a drawer menu with only HTML and CSS. Simple and clean.