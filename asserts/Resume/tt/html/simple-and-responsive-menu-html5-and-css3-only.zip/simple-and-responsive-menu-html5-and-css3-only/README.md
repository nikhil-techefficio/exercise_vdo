# Simple and Responsive Menu (HTML5 and CSS3 only)

A Pen created on CodePen.io. Original URL: [https://codepen.io/erinesullivan/pen/VQjzmZ](https://codepen.io/erinesullivan/pen/VQjzmZ).

A simple and responsive menu. HTML5 and CSS3 only. No jQuery. IE11 friendly.

The menu list was inspired by Bad Websites Examples: Top 50 Worst Websites Designs That Will Make You Cringe! by Ranking by SEO.