# Not-So-Spooky Ghost - Halloween 2020

A Pen created on CodePen.io. Original URL: [https://codepen.io/braydoncoyer/pen/ZEOxvdj](https://codepen.io/braydoncoyer/pen/ZEOxvdj).

