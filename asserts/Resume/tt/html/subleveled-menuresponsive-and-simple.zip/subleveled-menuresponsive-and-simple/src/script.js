/*Beta v0.1*/

/*
Project: Responsive Menu.
Project started: Decemeber 2013
Subject Info: 
A simple responsive navigaton. At the moment 100% free from andy type scripts.
Tech/Modular: HTML and CSS/MEDIA QUERIES 

Most Rescent Mods:
> June 4 2014 
* CASE 1 - Since subnavigation was visually shown in "WYSIWYG" editors the solution was to add "owerflow:no-display;" to the "#menu" in the CSS.

Prevoius Mods:
> Februari 2014
Setup and adjustment
Media Queries added
> May 2014
Working w. fixed topmeny(only in 960px+) and position
*/