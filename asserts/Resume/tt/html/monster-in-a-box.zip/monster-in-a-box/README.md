# Monster in a Box

A Pen created on CodePen.io. Original URL: [https://codepen.io/eduardosada/pen/GrJXzP](https://codepen.io/eduardosada/pen/GrJXzP).

Monster locked in a box made in pure HTML and CSS.