# Rotating Cards - CSS only

A Pen created on CodePen.io. Original URL: [https://codepen.io/shibl/pen/PzBwjR](https://codepen.io/shibl/pen/PzBwjR).

Rotating card with html and css only. no javascript.
