# icons with mouseover effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/palimadra/pen/AvPZXQ](https://codepen.io/palimadra/pen/AvPZXQ).

Pure html and css code for icons with image hover effect (zoom effect)