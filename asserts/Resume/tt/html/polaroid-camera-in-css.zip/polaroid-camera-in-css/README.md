# 📸 Polaroid Camera In CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/fossheim/pen/xxboBzO](https://codepen.io/fossheim/pen/xxboBzO).

I love cameras and I love CSS, so I decided to recreate a Polaroid camera in HTML and CSS. I only used divs and gradients, no images.

Tutorial: https://fossheim.io/writing/posts/css-polaroid-camera/

Code also available on:
https://glitch.com/~polaroid-css
https://github.com/sarahfossheim/polaroid-css