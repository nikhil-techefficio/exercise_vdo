# Orb Progress Bar

A Pen created on CodePen.io. Original URL: [https://codepen.io/benjammin412/pen/oNNzXY](https://codepen.io/benjammin412/pen/oNNzXY).

Progress Bar made only with HTML and CSS animation.