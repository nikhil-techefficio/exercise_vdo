# Block Reveal Effect HTML and CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/nirazanbasnet/pen/LKqKeZ](https://codepen.io/nirazanbasnet/pen/LKqKeZ).

This is just a sample of how we can create block reveal effect with just only with HTML and CSS animation.