# The Web Artisan Society #2

A Pen created on CodePen.io. Original URL: [https://codepen.io/syndicatefx/pen/XWajRJq](https://codepen.io/syndicatefx/pen/XWajRJq).

Handcrafted HTML and CSS titles and page heros