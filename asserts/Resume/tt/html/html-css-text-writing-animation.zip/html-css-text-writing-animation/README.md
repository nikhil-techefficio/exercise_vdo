# HTML / CSS text writing animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/aritzvelaz/pen/vYRvZe](https://codepen.io/aritzvelaz/pen/vYRvZe).

Only HTML and CSS