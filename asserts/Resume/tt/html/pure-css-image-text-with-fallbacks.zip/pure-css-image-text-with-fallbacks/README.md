# Pure CSS Image Text with Fallbacks

A Pen created on CodePen.io. Original URL: [https://codepen.io/KatieK2/pen/VwvjZB](https://codepen.io/KatieK2/pen/VwvjZB).

Pretty good support in modern browsers.

The H1 is text colored by a background image. This works well as of Firefox 51, Edge 38, Safari 10.0 Mobile, and Chrome 56. The fallback - white text over the image - works in FF 25, IE10, IE11.