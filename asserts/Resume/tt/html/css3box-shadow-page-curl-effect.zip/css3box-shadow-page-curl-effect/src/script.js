/* Source: http://matthamm.com/box-shadow-curl.html*/

/* Coding for ".box" was from the "Source" above. I am proud of myself on this Pen though...I was able to look at the CSS and figure out how to make the box-shadow effects on the other 3 boxes. I also added some formating to the body, header, etc. to finish the presentation of the Pen. */