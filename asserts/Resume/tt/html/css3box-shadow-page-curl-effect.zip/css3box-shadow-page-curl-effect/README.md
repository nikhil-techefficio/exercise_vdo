# CSS3 - Box Shadow: Page Curl Effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/bsmith/pen/yLWYNb](https://codepen.io/bsmith/pen/yLWYNb).

No Javascript. Just HTML and CSS.