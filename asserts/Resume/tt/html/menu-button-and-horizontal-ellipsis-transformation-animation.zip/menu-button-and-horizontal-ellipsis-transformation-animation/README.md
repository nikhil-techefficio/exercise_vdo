# Menu button and horizontal ellipsis transformation animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/himalayasingh/pen/KOdJPM](https://codepen.io/himalayasingh/pen/KOdJPM).

Menu button and horizontal ellipsis transformation animation using HTML and CSS.