# HTML CSS photo gallery

A Pen created on CodePen.io. Original URL: [https://codepen.io/palimadra/pen/AYELWV](https://codepen.io/palimadra/pen/AYELWV).

A beautiful photo gallery with HTML and CSS